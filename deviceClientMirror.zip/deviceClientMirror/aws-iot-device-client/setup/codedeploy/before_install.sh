#!/bin/sh
rm /sbin/aws-iot-device-client