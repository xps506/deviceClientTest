#!/bin/sh
chmod +x /sbin/aws-iot-device-client
systemctl start aws-iot-device-client.service