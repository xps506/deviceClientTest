#!/bin/sh
systemctl stop aws-iot-device-client.service