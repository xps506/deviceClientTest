// Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0

#ifndef AWS_IOT_DEVICE_CLIENT_SAMPLESHADOW_H
#define AWS_IOT_DEVICE_CLIENT_SAMPLESHADOW_H

#endif //AWS_IOT_DEVICE_CLIENT_SAMPLESHADOW_H

#include <aws/iot/MqttClient.h>
#include <aws/iotshadow/IotShadowClient.h>
#include "../ClientBaseNotifier.h"
#include "../Feature.h"
#include "../SharedCrtResourceManager.h"
#include "../config/Config.h"
#include "../util/FileUtils.h"



namespace Aws
{
    namespace Iot
    {
        namespace DeviceClient
        {
            namespace Shadow
            {
                class SampleShadowFeature : public Feature {
                public:
                    int init(
                            std::shared_ptr<SharedCrtResourceManager> manager,
                            std::shared_ptr<ClientBaseNotifier> notifier,
                            const PlainConfig &config);

                    // Interface methods defined in Feature.h
                    std::string getName() override;

                    int start() override;

                    int stop() override;

                private:
                    /**
                     * \brief the ThingName to use
                     */
                    std::string thingName;
                    static constexpr char TAG[] = "SampleShadowFeature.cpp";
                    /**
                     * \brief The resource manager used to manage CRT resources
                     */
                    std::shared_ptr<SharedCrtResourceManager> resourceManager;
                    /**
                     * \brief An interface used to notify the Client base if there is an event that requires its
                     * attention
                     */
                    std::shared_ptr<ClientBaseNotifier> baseNotifier;

                    std::string shadowName;

                    std::string inputFile;

                    std::string outputfile;

                    /**
                     * \brief Whether the DeviceClient base has requested this feature to stop
                     */
                    std::atomic<bool> needStop{false};


                    void updateNamedShadowAcceptedHandler(Iotshadow::UpdateShadowResponse *response,
                                                          int ioError);

                    void updateNamedShadowRejectedHandler(Iotshadow::ErrorResponse *errorResponse,
                                                          int ioError);

                    void updateNamedShadowEventHandler(Iotshadow::ShadowUpdatedEvent *shadowUpdatedEvent,
                                                       int ioError);

                    void updateNamedShadowDeltaHandler(Iotshadow::ShadowDeltaUpdatedEvent *shadowDeltaUpdatedEvent,
                                                       int ioError);


                    void subscribeToPertinentShadowTopics();

                    void ackSubscribeToUpdateNamedShadowAccepted(int ioError);

                    void ackSubscribeToUpdateNamedShadowRejected(int ioError);

                    void ackSubscribeToUpdateEvent(int ioError);

                    void ackSubscribeToUpdateDelta(int ioError);

                    /**
                     * \brief an IotShadowClient used to make calls to the AWS IoT Shadow service
                     */
                    std::unique_ptr<Aws::Iotshadow::IotShadowClient> shadowClient;

                    bool readAndUpdateShadowFromFile();

                    void runFileMonitor();

                    void ackUpdateNamedShadowStatus(int ioError);
                };
            }
        }
    }
}