// Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
// SPDX-License-Identifier: Apache-2.0

#include "SampleShadowFeature.h"
#include "../logging/LoggerFactory.h"
#include <aws/iotshadow/UpdateShadowResponse.h>
#include <aws/iotshadow/ErrorResponse.h>
#include <aws/iotshadow/IotShadowClient.h>
#include <aws/common/byte_buf.h>
#include <aws/crt/Api.h>
#include <aws/iotdevicecommon/IotDevice.h>
#include <iostream>

#include <utility>
#include <unistd.h>
#include <aws/crt/UUID.h>
#include <aws/iotshadow/UpdateNamedShadowSubscriptionRequest.h>
#include <aws/iotshadow/NamedShadowUpdatedSubscriptionRequest.h>
#include <aws/iotshadow/NamedShadowDeltaUpdatedSubscriptionRequest.h>
#include <aws/iotshadow/UpdateShadowRequest.h>
#include <aws/iotshadow/ShadowUpdatedEvent.h>
#include <aws/iotshadow/UpdateNamedShadowRequest.h>
#include <aws/iotshadow/ShadowDeltaUpdatedEvent.h>



using namespace std;
using namespace Aws;
using namespace Aws::Iot;
using namespace Aws::Crt;
using namespace Aws::Iotshadow;
using namespace Aws::Iot::DeviceClient::Shadow;
using namespace Aws::Crt::Mqtt;
using namespace Aws::Iot::DeviceClient::Util;
using namespace Aws::Iot::DeviceClient::Logging;

constexpr char SampleShadowFeature::TAG[];

#define EVENT_BUFSIZE 4096

string SampleShadowFeature::getName()
{
    return string("SampleShadow");
}

int SampleShadowFeature::init(
        shared_ptr<SharedCrtResourceManager> manager,
        shared_ptr<ClientBaseNotifier> notifier,
        const PlainConfig &config)
{
    resourceManager = manager;
    baseNotifier = notifier;
    thingName = *config.thingName;
    shadowName = config.sampleShadow.shadowName.value();
    inputFile = config.sampleShadow.shadowInputFile.value();
    outputfile = config.sampleShadow.shadowOutputFile.value();

    return AWS_OP_SUCCESS;
}

void SampleShadowFeature::updateNamedShadowAcceptedHandler(Iotshadow::UpdateShadowResponse *response, int ioError) {
    if (ioError)
    {
        LOGM_ERROR(TAG, "Encountered ioError %d within updateNamedShadowAcceptedHandler", ioError);
        return;
    }

    //do sth to sync with update/document topic

}

void SampleShadowFeature::updateNamedShadowRejectedHandler(Iotshadow::ErrorResponse *errorResponse, int ioError) {
    if (ioError)
    {
        LOGM_ERROR(TAG, "Encountered ioError %d within updateNamedShadowRejectedHandler", ioError);
        return;
    }

    if (errorResponse->Message.has_value())
    {
        LOGM_ERROR(TAG, "updateNamedShadow rejected: %s", errorResponse->Message->c_str());
    }
}

void SampleShadowFeature::updateNamedShadowEventHandler(Iotshadow::ShadowUpdatedEvent *shadowUpdatedEvent, int ioError) {
    if (ioError)
    {
        LOGM_ERROR(TAG, "Encountered ioError %d within updateNamedShadowEventHandler", ioError);
        return;
    }

    //write the response to output file
    Crt::JsonObject object;
    shadowUpdatedEvent->SerializeToObject(object);
    if(FileUtils::StoreValueInFile(object.View().WriteReadable(true).c_str(), outputfile)){
        LOGM_INFO(TAG, "Stored the latest %s shadow document to local successfully", shadowName.c_str());
    }
    else{
        LOGM_ERROR(TAG, "Failed to store latest %s shadow document to local", shadowName.c_str());
    }
}

void SampleShadowFeature::updateNamedShadowDeltaHandler(Iotshadow::ShadowDeltaUpdatedEvent *shadowDeltaUpdatedEvent,
                                                        int ioError) {
    if (ioError)
    {
        LOGM_ERROR(TAG, "Encountered ioError %d within updateNamedShadowDeltaHandler", ioError);
        return;
    }

    // do the shadow sync
    UpdateNamedShadowRequest updateNamedShadowRequest;
    updateNamedShadowRequest.ThingName = thingName;
    updateNamedShadowRequest.ShadowName = shadowName;
    updateNamedShadowRequest.State->Reported = shadowDeltaUpdatedEvent->State.value();
    Aws::Crt::UUID uuid;
    updateNamedShadowRequest.ClientToken = uuid.ToString();

    shadowClient->PublishUpdateNamedShadow(
            updateNamedShadowRequest,
            AWS_MQTT_QOS_AT_LEAST_ONCE,
            std::bind(&SampleShadowFeature::ackUpdateNamedShadowStatus, this, std::placeholders::_1)
    );
}

void SampleShadowFeature::ackSubscribeToUpdateNamedShadowAccepted(int ioError) {
    LOGM_DEBUG(TAG, "Ack received for SubscribeToUpdateNamedShadowAccepted with code {%d}", ioError);
    if (ioError)
    {
        string errorMessage = "Encountered an ioError while attempting to subscribe to UpdateNamedShadowAccepted";
        LOG_ERROR(TAG, errorMessage.c_str());
        baseNotifier->onError(this, ClientBaseErrorNotification::SUBSCRIPTION_FAILED, errorMessage);
    }
}

void SampleShadowFeature::ackSubscribeToUpdateNamedShadowRejected(int ioError) {
    LOGM_DEBUG(TAG, "Ack received for SubscribeToUpdateNamedShadowRejected with code {%d}", ioError);
    if (ioError)
    {
        string errorMessage = "Encountered an ioError while attempting to subscribe to UpdateNamedShadowRejected";
        LOG_ERROR(TAG, errorMessage.c_str());
        baseNotifier->onError(this, ClientBaseErrorNotification::SUBSCRIPTION_FAILED, errorMessage);
    }
}

void SampleShadowFeature::ackSubscribeToUpdateEvent(int ioError) {
    LOGM_DEBUG(TAG, "Ack received for SubscribeToUpdateNamedShadowEvent with code {%d}", ioError);
    if (ioError)
    {
        string errorMessage = "Encountered an ioError while attempting to subscribe to UpdateNamedShadowEvent";
        LOG_ERROR(TAG, errorMessage.c_str());
        baseNotifier->onError(this, ClientBaseErrorNotification::SUBSCRIPTION_FAILED, errorMessage);
    }
}

void SampleShadowFeature::ackSubscribeToUpdateDelta(int ioError) {
    LOGM_DEBUG(TAG, "Ack received for SubscribeToUpdateNamedShadowDelta with code {%d}", ioError);
    if (ioError)
    {
        string errorMessage = "Encountered an ioError while attempting to subscribe to UpdateNamedShadowDelta";
        LOG_ERROR(TAG, errorMessage.c_str());
        baseNotifier->onError(this, ClientBaseErrorNotification::SUBSCRIPTION_FAILED, errorMessage);
    }
}

void SampleShadowFeature::ackUpdateNamedShadowStatus(int ioError) {
    LOGM_DEBUG(TAG, "Ack received for updateNamedShadowStatus with code {%d}", ioError);
}

void SampleShadowFeature::subscribeToPertinentShadowTopics(){
    UpdateNamedShadowSubscriptionRequest updateNamedShadowSubscriptionRequest;
    updateNamedShadowSubscriptionRequest.ThingName = thingName;
    updateNamedShadowSubscriptionRequest.ShadowName = shadowName;

    shadowClient->SubscribeToUpdateNamedShadowAccepted(
            updateNamedShadowSubscriptionRequest,
            AWS_MQTT_QOS_AT_LEAST_ONCE,
            std::bind(&SampleShadowFeature::updateNamedShadowAcceptedHandler, this, std::placeholders::_1, std::placeholders::_2),
            std::bind(&SampleShadowFeature::ackSubscribeToUpdateNamedShadowAccepted, this, std::placeholders::_1));

    shadowClient->SubscribeToUpdateNamedShadowRejected(
            updateNamedShadowSubscriptionRequest,
            AWS_MQTT_QOS_AT_LEAST_ONCE,
            std::bind(&SampleShadowFeature::updateNamedShadowRejectedHandler, this, std::placeholders::_1, std::placeholders::_2),
            std::bind(&SampleShadowFeature::ackSubscribeToUpdateNamedShadowRejected, this, std::placeholders::_1));

    NamedShadowUpdatedSubscriptionRequest namedShadowUpdatedSubscriptionRequest;
    namedShadowUpdatedSubscriptionRequest.ThingName = thingName;
    namedShadowUpdatedSubscriptionRequest.ShadowName = shadowName;

    shadowClient->SubscribeToNamedShadowUpdatedEvents(
            namedShadowUpdatedSubscriptionRequest,
            AWS_MQTT_QOS_AT_LEAST_ONCE,
            std::bind(&SampleShadowFeature::updateNamedShadowEventHandler, this, std::placeholders::_1, std::placeholders::_2),
            std::bind(&SampleShadowFeature::ackSubscribeToUpdateEvent, this, std::placeholders::_1));

    NamedShadowDeltaUpdatedSubscriptionRequest namedShadowDeltaUpdatedSubscriptionRequest;
    namedShadowDeltaUpdatedSubscriptionRequest.ThingName = thingName;
    namedShadowDeltaUpdatedSubscriptionRequest.ShadowName = shadowName;


    shadowClient->SubscribeToNamedShadowDeltaUpdatedEvents(
            namedShadowDeltaUpdatedSubscriptionRequest,
            AWS_MQTT_QOS_AT_LEAST_ONCE,
            std::bind(&SampleShadowFeature::updateNamedShadowDeltaHandler, this, std::placeholders::_1, std::placeholders::_2),
            std::bind(&SampleShadowFeature::ackSubscribeToUpdateDelta, this, std::placeholders::_1));

}

void SampleShadowFeature::readAndUpdateShadowFromFile (){

    string expandedPath = FileUtils::ExtractExpandedPath(inputFile);
    if (!FileUtils::FileExists(expandedPath))
    {
        LOGM_DEBUG(TAG, "Unable to open shadow data file %s, file does not exist", Sanitize(expandedPath).c_str());
    }

    size_t incomingFileSize = FileUtils::GetFileSize(inputFile);
    if (4 * 1024 < incomingFileSize)
    {
        LOGM_WARN(
                TAG,
                "Refusing to open config file %s, file size %zu bytes is greater than allowable limit of %zu bytes",
                Sanitize(inputFile).c_str(),
                incomingFileSize,
                4 * 1024);
    }

    ifstream setting(expandedPath.c_str());
    if (!setting.is_open())
    {
        LOGM_ERROR(TAG, "Unable to open file: '%s'", Sanitize(expandedPath).c_str());
    }

    std::string contents((std::istreambuf_iterator<char>(setting)), std::istreambuf_iterator<char>());
    Crt::JsonObject jsonObj = Aws::Crt::JsonObject(contents.c_str());
    if (!jsonObj.WasParseSuccessful())
    {
        LOGM_ERROR(
                TAG, "Couldn't parse JSON shadow data file. GetErrorMessage returns: %s", jsonObj.GetErrorMessage().c_str());
    }

    UpdateNamedShadowRequest updateNamedShadowRequest;
    updateNamedShadowRequest.ThingName = thingName;
    updateNamedShadowRequest.ShadowName = shadowName;
    updateNamedShadowRequest.State->Desired = jsonObj;
    updateNamedShadowRequest.State->Reported = jsonObj;

    Aws::Crt::UUID uuid;
    updateNamedShadowRequest.ClientToken = uuid.ToString();

    shadowClient->PublishUpdateNamedShadow(
            updateNamedShadowRequest,
            AWS_MQTT_QOS_AT_LEAST_ONCE,
            std::bind(&SampleShadowFeature::ackUpdateNamedShadowStatus, this, std::placeholders::_1)
            );

    LOGM_INFO(TAG, "Successfully Update the shadow with local data file: %s", Sanitize(contents).c_str());
    setting.close();
}

void SampleShadowFeature::runFileMonitor() {
    int len = 0;
    string fileDir = FileUtils::ExtractParentDirectory(inputFile.c_str());
    string fileName = inputFile.substr(fileDir.length());
    char buf[EVENT_BUFSIZE], *cur = buf, *end;

    int fd, dir_wd, file_wd;

    fd = inotify_init();

    if (fd == -1) {
        LOGM_ERROR(
            TAG, "Encounter error %d while initializing the inode notify system return s%", fd);
        return;
    }

    dir_wd = inotify_add_watch(fd, fileDir.c_str(), IN_CREATE);
    if (dir_wd == -1) {
        LOGM_ERROR(
            TAG, "Encounter error %d while adding the watch for input file's parent directory", fd);
        goto exit;
    }

    file_wd = inotify_add_watch(fd, inputFile.c_str(), IN_CLOSE_WRITE);
    if (file_wd == -1) {
        LOGM_ERROR(
            TAG, "Encounter error %d while adding the watch for target file", fd);
        goto exit;
    }

    LOGM_DEBUG(TAG, "Start monitor the target file s%", inputFile.c_str());

    while(!needStop.load()){
        len = read(fd, cur, EVENT_BUFSIZE - len);
        LOG_WARN(
            TAG, "Couldn't monitor ant more target file modify events as it reaches max read buffer size");
        goto exit;
        end = cur + len;

        while (cur + sizeof(struct inotify_event) <= end) {
            struct inotify_event* e = (struct inotify_event*)cur;

            if (cur + sizeof(struct inotify_event) + e->len > end)
                break;

            if (e->mask & IN_CREATE) {
                if (strcmp(e->name, fileName.c_str()) != 0)
                    goto next;

                if (e->mask & IN_ISDIR)
                    goto next;

                LOG_DEBUG(TAG, "New file is created with the same name of target file, start updating the shadow");
                readAndUpdateShadowFromFile();
                file_wd = inotify_add_watch(fd, inputFile.c_str(), IN_CLOSE_WRITE | IN_DELETE_SELF);
            }


            if (e->mask & IN_CLOSE_WRITE){
                LOG_DEBUG(TAG, "The target file is modified, start updating the shadow");
                readAndUpdateShadowFromFile();
            }


            if (e->mask & IN_DELETE_SELF) {
                if (e->mask & IN_ISDIR)
                    goto next;

                LOG_DEBUG(TAG, "The target file is deleted by itself, removing the watch");
                inotify_rm_watch(fd, file_wd);
            }

            next:
            cur += sizeof(struct inotify_event) + e->len;
        }

        if (cur >= end) {
            cur = buf;
            len = 0;
        } else {
            len = end - cur;
            memmove(buf, cur, len);
            cur = buf + len;
        }
    }

    exit:
    close(fd);
    return;
}

int SampleShadowFeature::start() {
    LOGM_INFO(TAG, "Starting %s", getName().c_str());

    shadowClient = unique_ptr<IotShadowClient>(new IotShadowClient(resourceManager.get()->getConnection()));
    subscribeToPertinentShadowTopics();
    readAndUpdateShadowFromFile();
    runFileMonitor();

    baseNotifier->onEvent((Feature *)this, ClientBaseEventNotification::FEATURE_STARTED);
    return AWS_OP_SUCCESS;
}

int SampleShadowFeature::stop() {
    needStop.store(true);
    baseNotifier->onEvent((Feature *)this, ClientBaseEventNotification::FEATURE_STOPPED);
    return AWS_OP_SUCCESS;
}



