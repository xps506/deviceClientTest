#!/bin/sh
cd /root/aws-iot-device-client/.github/
chmod +x ./build.sh
./build.sh $1